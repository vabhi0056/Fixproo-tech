# Fixproo Enterprise Web Application

This repository contains the source code and build artifacts for the Fixproo Tech Solutions web platform.

## Project Architecture

This project utilizes a modern component-based architecture optimized for performance and scalability.

### Directory Structure

*   `build/` - Production-ready minified build. **(Deploy this folder)**.
*   `src/` - Source code with modular components.
*   `config/` - Webpack and environment configurations.
*   `package.json` - Dependency management.

## Deployment Instructions

For immediate client delivery, utilize the pre-compiled bundle in the `build` directory.

1.  Navigate to `build/`.
2.  Deploy the contents to your hosting provider (Vercel, Netlify, Apache, Nginx).
3.  Ensure cache-control headers are set for immutable assets in `static/`.

## Developer Setup

```bash
# Install dependencies
npm install

# Start development server
npm start

# Create production build
npm run build
```

## Tech Stack

*   **Core**: React 18, ES6+
*   **Styling**: SCSS, PostCSS, CSS Modules
*   **Animation**: GSAP, Framer Motion
*   **Build**: Webpack 5, Babel

---
© 2026 Fixproo Tech Solutions. All Rights Reserved.
